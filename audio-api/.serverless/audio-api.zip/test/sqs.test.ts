import { publishToQueue } from '../src/sqs';
import { MockSQSClient } from './mocks';

describe('SQS Message Publishing', () => {
  let mockSQS: MockSQSClient;

  beforeEach(() => {
    mockSQS = new MockSQSClient();
  });

  it('should send SQS message with correct payload', async () => {
    const queueUrl = 'https://sqs.us-east-1.amazonaws.com/123456789/test-queue';
    const text = 'tere';
    const hash = 'abc123';
    
    await publishToQueue(mockSQS as any, queueUrl, text, hash);
    
    expect(mockSQS.messages).toHaveLength(1);
    expect(mockSQS.messages[0].QueueUrl).toBe(queueUrl);
    
    const messageBody = JSON.parse(mockSQS.messages[0].MessageBody);
    expect(messageBody.text).toBe(text);
    expect(messageBody.hash).toBe(hash);
  });

  it('should include all required fields in message', async () => {
    const queueUrl = 'https://sqs.us-east-1.amazonaws.com/123456789/test-queue';
    const text = 'tere';
    const hash = 'abc123';
    
    await publishToQueue(mockSQS as any, queueUrl, text, hash);
    
    const messageBody = JSON.parse(mockSQS.messages[0].MessageBody);
    expect(messageBody.text).toBeDefined();
    expect(messageBody.hash).toBeDefined();
    expect(messageBody.timestamp).toBeDefined();
    expect(typeof messageBody.timestamp).toBe('number');
  });

  it('should handle publish errors', async () => {
    const mockSQSWithError = {
      sendMessage: async () => {
        throw new Error('Queue not found');
      }
    };
    
    await expect(publishToQueue(mockSQSWithError, 'invalid-queue', 'tere', 'abc123'))
      .rejects.toThrow('Queue not found');
  });
});
